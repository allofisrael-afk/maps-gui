"""הפעלת הממשק הגרפי: python run_gui.py"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if os.name == "nt":
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)  # טקסט חד במסכי High-DPI
    except Exception:
        pass

from mpm.gui import main

if __name__ == "__main__":
    main()
