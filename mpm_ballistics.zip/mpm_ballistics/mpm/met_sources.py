"""מקורות מטאו: תחזית חיה מ-Open-Meteo, חיפוש מיקום לפי שם, וקובץ מטאו CSV.

Open-Meteo חינמי ואינו דורש מפתח. הנתונים מגיעים ממודלים נומריים (ברירת מחדל: best_match),
בשכבות לחץ 1000–30 hPa (עד כ-24 ק"מ), ברזולוציה שעתית.
"""
import csv
import json
import math
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from .atmosphere import AtmosphereProfile

PRESSURE_LEVELS = [1000, 975, 950, 925, 900, 850, 800, 700, 600, 500, 400, 300, 250, 200, 150, 100, 70, 50, 30]
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
USER_AGENT = "MPM-Ballistics/1.0"
TIMEOUT = 20


def _get_json(url, params):
    full = url + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(full, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")[:300]
        raise ConnectionError(f"שגיאת שרת {e.code}: {body}") from e
    except urllib.error.URLError as e:
        raise ConnectionError(f"אין חיבור לשירות המטאו: {e.reason}") from e


def geocode(name, count=8, language="he"):
    """חיפוש מיקום לפי שם (עברית או אנגלית). מחזיר רשימת מילונים."""
    d = _get_json(GEOCODE_URL, {"name": name, "count": count, "language": language, "format": "json"})
    out = []
    for r in d.get("results", []) or []:
        label = ", ".join(x for x in (r.get("name"), r.get("admin1"), r.get("country")) if x)
        out.append({"label": label, "lat": r["latitude"], "lon": r["longitude"], "elevation_m": r.get("elevation")})
    return out


def fetch_open_meteo(lat, lon, when_utc=None):
    """
    מושך פרופיל מטאו לשעה הקרובה ביותר ל-when_utc (ברירת מחדל: עכשיו).
    מחזיר (surface, levels, meta) בפורמט של AtmosphereProfile.from_levels.
    """
    hourly = ["temperature_2m", "surface_pressure", "wind_speed_10m", "wind_direction_10m"]
    for p in PRESSURE_LEVELS:
        hourly += [f"temperature_{p}hPa", f"wind_speed_{p}hPa", f"wind_direction_{p}hPa", f"geopotential_height_{p}hPa"]
    when = when_utc or datetime.now(timezone.utc)
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    params = {
        "latitude": f"{lat:.5f}", "longitude": f"{lon:.5f}",
        "hourly": ",".join(hourly), "wind_speed_unit": "ms", "timezone": "UTC",
        "start_hour": when.strftime("%Y-%m-%dT%H:00"), "end_hour": when.strftime("%Y-%m-%dT%H:00"),
    }
    d = _get_json(FORECAST_URL, params)
    if d.get("error"):
        raise ConnectionError(d.get("reason", "שגיאה לא ידועה מ-Open-Meteo"))
    H = d["hourly"]
    times = H["time"]
    if not times:
        raise ValueError("לא התקבלו נתונים לשעה המבוקשת")
    i = 0

    def val(key):
        v = H.get(key)
        return None if v is None else v[i]

    elev = float(d.get("elevation") or 0.0)
    surface = {
        "alt_m": elev,
        "temp_c": val("temperature_2m"),
        "pressure_hpa": val("surface_pressure"),
        "wind_speed_mps": val("wind_speed_10m") or 0.0,
        "wind_dir_deg": val("wind_direction_10m") or 0.0,
    }
    if surface["temp_c"] is None or surface["pressure_hpa"] is None:
        raise ValueError("חסרים נתוני קרקע בתחזית")
    levels = []
    for p in PRESSURE_LEVELS:
        h, t = val(f"geopotential_height_{p}hPa"), val(f"temperature_{p}hPa")
        ws, wd = val(f"wind_speed_{p}hPa"), val(f"wind_direction_{p}hPa")
        if None in (h, t):
            continue
        if h <= elev + 10:
            continue  # שכבה מתחת לפני הקרקע
        levels.append({"height_m": h, "temp_c": t, "pressure_hpa": p,
                       "wind_speed_mps": ws or 0.0, "wind_dir_deg": wd or 0.0})
    meta = {"source": "open-meteo", "valid_time_utc": times[0], "lat": d.get("latitude"),
            "lon": d.get("longitude"), "model_elevation_m": elev, "levels": len(levels)}
    return surface, levels, meta


def profile_from_open_meteo(lat, lon, when_utc=None, site_alt=None):
    surface, levels, meta = fetch_open_meteo(lat, lon, when_utc)
    if site_alt is not None and abs(site_alt - surface["alt_m"]) > 1:
        # התאמת הקרקע לגובה התותח האמיתי (לחץ לפי הידרוסטטיקה, טמפ' לפי קצב סטנדרטי)
        dz = site_alt - surface["alt_m"]
        T = surface["temp_c"] + 273.15
        surface = dict(surface)
        surface["pressure_hpa"] = surface["pressure_hpa"] * math.exp(-9.80665 * dz / (287.05 * (T - 0.00325 * dz)))
        surface["temp_c"] = surface["temp_c"] - 0.0065 * dz
        surface["alt_m"] = site_alt
        meta["site_alt_adjusted_m"] = round(dz, 1)
    prof = AtmosphereProfile.from_levels(surface, levels, f"Open-Meteo {meta['valid_time_utc']} UTC")
    return prof, meta


def load_met_csv(path):
    """
    קובץ מטאו CSV. עמודות: height_m (מעל פני הים), temp_c, wind_speed_mps, wind_dir_deg, pressure_hpa
    השורה הנמוכה ביותר היא הקרקע; pressure_hpa חובה רק בה.
    """
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = [{k.strip().lower(): (v.strip() if isinstance(v, str) else v) for k, v in r.items()}
                for r in csv.DictReader(f)]
    rows = [r for r in rows if r.get("height_m")]
    if len(rows) < 1:
        raise ValueError("קובץ המטאו ריק")
    rows.sort(key=lambda r: float(r["height_m"]))
    s = rows[0]
    if not s.get("pressure_hpa"):
        raise ValueError("בשורת הקרקע (הנמוכה ביותר) חסר pressure_hpa")
    surface = {"alt_m": float(s["height_m"]), "temp_c": float(s["temp_c"]),
               "pressure_hpa": float(s["pressure_hpa"]),
               "wind_speed_mps": float(s.get("wind_speed_mps") or 0), "wind_dir_deg": float(s.get("wind_dir_deg") or 0)}
    levels = [{"height_m": float(r["height_m"]), "temp_c": float(r["temp_c"]),
               "wind_speed_mps": float(r.get("wind_speed_mps") or 0), "wind_dir_deg": float(r.get("wind_dir_deg") or 0)}
              for r in rows[1:]]
    return AtmosphereProfile.from_levels(surface, levels, "Met CSV")


def profile_from_spec(spec, site_alt):
    """
    בונה פרופיל ממפרט JSON (משמש את הגשר והממשק):
      {"source": "standard", "surface_temp_c"?, "surface_pressure_hpa"?, "wind_speed_mps"?, "wind_dir_deg"?}
      {"source": "open-meteo", "lat"?, "lon"?, "time_utc"?}     (ברירת מחדל: מיקום התותח)
      {"source": "inline", "surface": {...}, "levels": [...]}
      {"source": "csv", "path": "..."}
    מחזיר (profile, meta)
    """
    spec = spec or {"source": "standard"}
    src = (spec.get("source") or "standard").lower()
    if src == "standard":
        prof = AtmosphereProfile.standard(site_alt, spec.get("surface_temp_c"), spec.get("surface_pressure_hpa"),
                                          float(spec.get("wind_speed_mps") or 0.0), float(spec.get("wind_dir_deg") or 0.0))
        return prof, {"source": "standard"}
    if src == "inline":
        surface = dict(spec["surface"])
        surface.setdefault("alt_m", site_alt)
        prof = AtmosphereProfile.from_levels(surface, spec.get("levels", []), spec.get("description", "Inline met"))
        return prof, {"source": "inline", "valid_time_utc": spec.get("time_utc")}
    if src == "csv":
        return load_met_csv(spec["path"]), {"source": "csv", "path": spec["path"]}
    if src in ("open-meteo", "openmeteo", "live"):
        when = None
        if spec.get("time_utc"):
            when = datetime.fromisoformat(spec["time_utc"].replace("Z", "+00:00"))
        return profile_from_open_meteo(float(spec["lat"]), float(spec["lon"]), when, site_alt)
    raise ValueError(f"מקור מטאו לא מוכר: {src}")
