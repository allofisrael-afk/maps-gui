"""ממשק גרפי (Tkinter) לסימולציית MPM — 4 דרגות חופש.

כותרות הגרפים באנגלית, כי Matplotlib לא מציג עברית מימין לשמאל.
"""
import json
import math
import os
import queue
import threading
import traceback
from dataclasses import replace
from datetime import datetime, timezone

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

from . import __version__
from .atmosphere import AtmosphereProfile
from .bridge import watch, BASE_DIR
from .engine import FireParams, simulate, stability_warnings
from .fire_control import solve, firing_table, write_table_csv, calibrate, TABLE_COLUMNS
from .geodesy import inverse
from .met_sources import geocode, profile_from_open_meteo, load_met_csv, profile_from_spec
from .projectile import load_projectile
from .units import angle_to_rad, rad_to_mils, both

FONT = ("Segoe UI", 10)
FONT_B = ("Segoe UI", 10, "bold")
MONO = ("Consolas", 9)


def fmt_angle(d):
    return f"{d['mils']:.1f} מיל  ({d['deg']:.3f}°)"


class LabeledEntry:
    """שורת קלט מימין לשמאל: תווית בצד ימין, שדה בצד שמאל."""

    def __init__(self, parent, row, label, default="", width=12, col=0):
        self.var = tk.StringVar(value=str(default))
        self.entry = ttk.Entry(parent, textvariable=self.var, width=width, justify="left")
        self.entry.grid(row=row, column=col, sticky="we", padx=4, pady=2)
        ttk.Label(parent, text=label, anchor="e").grid(row=row, column=col + 1, sticky="e", padx=4, pady=2)

    def get(self, cast=float, allow_empty=False, name=""):
        s = self.var.get().strip()
        if s == "":
            if allow_empty:
                return None
            raise ValueError(f"שדה חסר: {name}")
        try:
            return cast(s)
        except ValueError:
            raise ValueError(f"ערך לא תקין בשדה {name}: {s}")

    def set(self, v):
        self.var.set(str(v))


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"סימולציית MPM — 4 דרגות חופש  (v{__version__})")
        self.geometry("1400x880")
        self.minsize(1100, 700)
        self.option_add("*Font", FONT)
        style = ttk.Style(self)
        try:
            style.theme_use("vista" if os.name == "nt" else "clam")
        except tk.TclError:
            pass
        style.configure("Accent.TButton", font=FONT_B)

        self.q = queue.Queue()
        self.busy = False
        self.atmo = None
        self.atmo_meta = None
        self.atmo_key = None
        self.projectile = load_projectile()
        self.bridge_stop = None
        self.last_table = []
        self.met_dirty = False

        self._build()
        self.after(100, self._poll)

    # ================= בנייה =================
    def _build(self):
        self.status = tk.StringVar(value="מוכן")
        bar = ttk.Frame(self, relief="sunken")
        bar.pack(side="bottom", fill="x")
        ttk.Label(bar, textvariable=self.status, anchor="e").pack(side="right", padx=6)
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=160)
        self.progress.pack(side="left", padx=6, pady=2)
        main = ttk.Frame(self)
        main.pack(fill="both", expand=True)
        # בממשק RTL: לוח ההגדרות בצד ימין, עם גלילה למסכים נמוכים
        holder = ttk.Frame(main)
        holder.pack(side="right", fill="y")
        sc = tk.Canvas(holder, width=380, highlightthickness=0)
        vs = ttk.Scrollbar(holder, orient="vertical", command=sc.yview)
        sc.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        sc.pack(side="right", fill="y")
        self.side = ttk.Frame(sc, padding=6)
        win = sc.create_window((0, 0), window=self.side, anchor="nw")
        self.side.bind("<Configure>", lambda e: sc.configure(scrollregion=sc.bbox("all"), width=self.side.winfo_reqwidth()))
        sc.bind("<Configure>", lambda e: sc.itemconfigure(win, width=e.width))
        sc.bind_all("<MouseWheel>", lambda e: sc.yview_scroll(int(-e.delta / 120), "units")
                    if str(e.widget).startswith(str(sc)) else None)
        self.nb = ttk.Notebook(main)
        self.nb.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        self._build_side()
        self._build_traj_tab()
        self._build_solve_tab()
        self._build_table_tab()
        self._build_cal_tab()
        self._build_met_tab()
        self._build_bridge_tab()

    def _section(self, parent, title):
        f = ttk.LabelFrame(parent, text=title, padding=6, labelanchor="ne")
        f.pack(fill="x", pady=4)
        f.columnconfigure(0, weight=1)
        return f

    def _build_side(self):
        s = self.side
        # ---- מיקום ----
        f = self._section(s, "מיקום התותח")
        row = ttk.Frame(f)
        row.grid(row=0, column=0, columnspan=2, sticky="we")
        self.place_var = tk.StringVar()
        ttk.Button(row, text="חפש", command=self.on_geocode, width=6).pack(side="left")
        ttk.Entry(row, textvariable=self.place_var, justify="right").pack(side="left", fill="x", expand=True, padx=4)
        ttk.Label(row, text="ישוב").pack(side="left")
        self.place_combo = ttk.Combobox(f, state="readonly", justify="right")
        self.place_combo.grid(row=1, column=0, columnspan=2, sticky="we", pady=2)
        self.place_combo.bind("<<ComboboxSelected>>", self.on_place_selected)
        self.places = []
        self.e_lat = LabeledEntry(f, 2, "קו רוחב [°]", "31.2520")
        self.e_lon = LabeledEntry(f, 3, "קו אורך [°]", "34.7915")
        self.e_alt = LabeledEntry(f, 4, "גובה לוע מעל פני הים [מ']", "280")

        # ---- מטאו ----
        f = self._section(s, "מטאו")
        self.met_src = tk.StringVar(value="live")
        for i, (v, t) in enumerate([("live", "תחזית חיה (Open-Meteo)"), ("standard", "אטמוספרה סטנדרטית"),
                                    ("csv", "קובץ מטאו CSV"), ("json", "קובץ מטאו JSON")]):
            ttk.Radiobutton(f, text=t, variable=self.met_src, value=v, command=self._met_src_changed).grid(
                row=i, column=0, columnspan=2, sticky="e")
        self.e_time = LabeledEntry(f, 4, "שעת תחזית UTC (ריק = עכשיו)", "")
        self.e_temp = LabeledEntry(f, 5, "טמפ' בקרקע [°C] (ריק = סטנדרט)", "")
        self.e_pres = LabeledEntry(f, 6, "לחץ בקרקע [hPa] (ריק = סטנדרט)", "")
        self.e_wspd = LabeledEntry(f, 7, "מהירות רוח [מ'/ש']", "0")
        self.e_wdir = LabeledEntry(f, 8, "כיוון רוח, נושבת מ- [°]", "0")
        self.met_file = tk.StringVar()
        row = ttk.Frame(f)
        row.grid(row=9, column=0, columnspan=2, sticky="we")
        ttk.Button(row, text="בחר קובץ…", command=self.on_pick_met).pack(side="left")
        ttk.Label(row, textvariable=self.met_file, anchor="e", width=24).pack(side="left", fill="x", expand=True)
        ttk.Button(f, text="טען מטאו", command=self.on_load_met).grid(row=10, column=0, columnspan=2, sticky="we", pady=3)
        self.met_status = tk.StringVar(value="מטאו לא נטען — ייטען אוטומטית בחישוב הראשון")
        ttk.Label(f, textvariable=self.met_status, wraplength=300, anchor="e", justify="right",
                  foreground="#555").grid(row=11, column=0, columnspan=2, sticky="e")

        # ---- פגז ----
        f = self._section(s, "פגז ותותח")
        self.proj_name = tk.StringVar(value=self.projectile.name)
        ttk.Label(f, textvariable=self.proj_name, wraplength=300, anchor="e", justify="right").grid(
            row=0, column=0, columnspan=2, sticky="e")
        ttk.Button(f, text="טען קובץ פגז (JSON)…", command=self.on_load_proj).grid(row=1, column=0, columnspan=2, sticky="we", pady=2)
        self.e_mv = LabeledEntry(f, 2, "מהירות לוע [מ'/ש']", "684")

        # ---- מקדמי התאמה וחישוב ----
        f = self._section(s, "מקדמי התאמה וחישוב")
        self.e_fd = LabeledEntry(f, 0, "מקדם גרר fD", "1.0")
        self.e_fl = LabeledEntry(f, 1, "מקדם עילוי fL", "1.0")
        self.e_dt = LabeledEntry(f, 2, "צעד אינטגרציה [ש']", "0.02")
        self.unit = tk.StringVar(value="mils")
        row = ttk.Frame(f)
        row.grid(row=3, column=0, columnspan=2, sticky="e")
        ttk.Radiobutton(row, text="מעלות", variable=self.unit, value="deg").pack(side="left")
        ttk.Radiobutton(row, text="מילים", variable=self.unit, value="mils").pack(side="left")
        ttk.Label(row, text=":יחידות קלט").pack(side="left")
        self.coriolis = tk.BooleanVar(value=True)
        self.curv = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="קוריוליס", variable=self.coriolis).grid(row=4, column=0, columnspan=2, sticky="e")
        ttk.Checkbutton(f, text="עקמומיות כדור הארץ", variable=self.curv).grid(row=5, column=0, columnspan=2, sticky="e")
        self._met_src_changed()

    def _make_output(self, parent):
        pane = ttk.PanedWindow(parent, orient="horizontal")
        pane.pack(fill="both", expand=True, pady=4)
        fig_frame = ttk.Frame(pane)
        txt_frame = ttk.Frame(pane)
        pane.add(fig_frame, weight=5)
        pane.add(txt_frame, weight=4)
        fig = Figure(figsize=(7, 6), dpi=96, constrained_layout=True)
        canvas = FigureCanvasTkAgg(fig, master=fig_frame)
        NavigationToolbar2Tk(canvas, fig_frame).update()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        txt = tk.Text(txt_frame, wrap="word", font=MONO, width=48)
        sb = ttk.Scrollbar(txt_frame, command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        txt.tag_configure("r", justify="right")
        txt.tag_configure("h", justify="right", font=FONT_B)
        txt.tag_configure("w", justify="right", foreground="#b00020")
        return fig, canvas, txt

    def _build_traj_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  מסלול בודד  ")
        top = ttk.Frame(t)
        top.pack(fill="x")
        self.t_qe = LabeledEntry(top, 0, "זווית הגבהה", "450", col=4)
        self.t_az = LabeledEntry(top, 0, "אזימוט ירי", "600", col=2)
        self.t_talt = LabeledEntry(top, 0, "גובה נקודת פגיעה מעל פני הים [מ'] (ריק = גובה התותח)", "", col=0)
        self.btn_traj = ttk.Button(top, text="חשב מסלול", style="Accent.TButton", command=self.on_traj)
        self.btn_traj.grid(row=1, column=0, columnspan=6, sticky="e", pady=4)
        self.traj_fig, self.traj_canvas, self.traj_txt = self._make_output(t)

    def _build_solve_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  פתרון ירי  ")
        top = ttk.Frame(t)
        top.pack(fill="x")
        self.s_mode = tk.StringVar(value="coords")
        r = ttk.Frame(top)
        r.grid(row=0, column=0, columnspan=6, sticky="e")
        ttk.Radiobutton(r, text="טווח ואזימוט", variable=self.s_mode, value="polar").pack(side="left", padx=6)
        ttk.Radiobutton(r, text="קואורדינטות מטרה", variable=self.s_mode, value="coords").pack(side="left", padx=6)
        ttk.Label(r, text=":הגדרת מטרה", font=FONT_B).pack(side="left")
        self.s_lat = LabeledEntry(top, 1, "קו רוחב מטרה [°]", "31.3600", col=4)
        self.s_lon = LabeledEntry(top, 1, "קו אורך מטרה [°]", "34.8900", col=2)
        self.s_talt = LabeledEntry(top, 1, "גובה מטרה מעל פני הים [מ']", "310", col=0)
        self.s_rng = LabeledEntry(top, 2, "טווח אופקי [מ']", "15000", col=4)
        self.s_az = LabeledEntry(top, 2, "אזימוט למטרה", "680", col=2)
        self.s_group = tk.StringVar(value="low")
        r = ttk.Frame(top)
        r.grid(row=2, column=0, columnspan=2, sticky="e")
        ttk.Radiobutton(r, text="גבוהה", variable=self.s_group, value="high").pack(side="left")
        ttk.Radiobutton(r, text="נמוכה", variable=self.s_group, value="low").pack(side="left")
        ttk.Label(r, text=":קבוצת זוויות").pack(side="left")
        self.btn_solve = ttk.Button(top, text="חשב פתרון ירי", style="Accent.TButton", command=self.on_solve)
        self.btn_solve.grid(row=3, column=0, columnspan=6, sticky="e", pady=4)
        self.solve_fig, self.solve_canvas, self.solve_txt = self._make_output(t)

    def _build_table_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  טבלת ירי  ")
        top = ttk.Frame(t)
        top.pack(fill="x")
        self.tb_start = LabeledEntry(top, 0, "הגבהה מ-", "100", col=6)
        self.tb_end = LabeledEntry(top, 0, "עד", "1200", col=4)
        self.tb_step = LabeledEntry(top, 0, "צעד", "50", col=2)
        self.tb_az = LabeledEntry(top, 0, "אזימוט ירי", "0", col=0)
        r = ttk.Frame(top)
        r.grid(row=1, column=0, columnspan=8, sticky="e", pady=4)
        ttk.Button(r, text="ייצוא CSV…", command=self.on_export_table).pack(side="left", padx=4)
        self.btn_table = ttk.Button(r, text="חשב טבלה", style="Accent.TButton", command=self.on_table)
        self.btn_table.pack(side="left")
        heads = {"qe_mils": "הגבהה [מיל]", "qe_deg": "הגבהה [°]", "range_m": "טווח [מ']", "drift_mils": "סחיפה [מיל]",
                 "drift_m": "סחיפה [מ']", "tof_s": "זמן מעוף [ש']", "apex_m": "קודקוד [מ']",
                 "impact_vel_mps": "מהירות פגיעה", "fall_angle_mils": "זווית נפילה [מיל]",
                 "fall_angle_deg": "זווית נפילה [°]", "sg_min": "Sg מינ'"}
        cols = list(reversed(TABLE_COLUMNS))  # RTL
        fr = ttk.Frame(t)
        fr.pack(fill="both", expand=True)
        self.table = ttk.Treeview(fr, columns=cols, show="headings")
        for c in cols:
            self.table.heading(c, text=heads[c])
            self.table.column(c, width=82, minwidth=60, anchor="center", stretch=True)
        sb = ttk.Scrollbar(fr, command=self.table.yview)
        self.table.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y")
        self.table.pack(side="left", fill="both", expand=True)
        self.table_warn = tk.StringVar()
        ttk.Label(t, textvariable=self.table_warn, foreground="#b00020", anchor="e", justify="right",
                  wraplength=900).pack(fill="x")

    def _build_cal_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  כיול  ")
        ttk.Label(t, anchor="e", justify="right", wraplength=900, text=(
            "הזן נקודות פגיעה שנמדדו בירי אמיתי, בתנאי המטאו שנטענו. התוכנה מחשבת מקדם גרר (fD) "
            "שמתאים את הטווחים, ומקדם עילוי (fL) שמתאים את הסחיפה. סחיפה: ימינה חיובי, ביחידת הקלט שנבחרה.")).pack(fill="x")
        top = ttk.Frame(t)
        top.pack(fill="x", pady=4)
        self.c_qe = LabeledEntry(top, 0, "הגבהה", "300", col=8)
        self.c_az = LabeledEntry(top, 0, "אזימוט", "1600", col=6)
        self.c_rng = LabeledEntry(top, 0, "טווח שנמדד [מ']", "", col=4)
        self.c_dr = LabeledEntry(top, 0, "סחיפה שנמדדה (ריק = אין)", "", col=2)
        self.c_talt = LabeledEntry(top, 0, "גובה פגיעה [מ'] (ריק = גובה התותח)", "", col=0)
        r = ttk.Frame(t)
        r.pack(fill="x")
        self.btn_apply = ttk.Button(r, text="החל מקדמים", command=self.on_apply_fit, state="disabled")
        self.btn_apply.pack(side="left", padx=4)
        self.btn_cal = ttk.Button(r, text="כייל", style="Accent.TButton", command=self.on_calibrate)
        self.btn_cal.pack(side="left", padx=4)
        ttk.Button(r, text="נקה הכל", command=lambda: self.cal_tree.delete(*self.cal_tree.get_children())).pack(side="right", padx=4)
        ttk.Button(r, text="מחק נבחרת", command=lambda: [self.cal_tree.delete(i) for i in self.cal_tree.selection()]).pack(side="right", padx=4)
        ttk.Button(r, text="הוסף נקודה", command=self.on_add_cal).pack(side="right", padx=4)
        cols = ("talt", "sim_dr", "dr", "err", "sim_rng", "rng", "az", "qe")
        heads = ("גובה פגיעה", "סחיפה מחושבת", "סחיפה נמדדת", "שגיאת טווח [מ']", "טווח מחושב", "טווח נמדד", "אזימוט", "הגבהה")
        self.cal_tree = ttk.Treeview(t, columns=cols, show="headings", height=10)
        for c, h in zip(cols, heads):
            self.cal_tree.heading(c, text=h)
            self.cal_tree.column(c, width=100, minwidth=60, anchor="center", stretch=True)
        self.cal_tree.pack(fill="both", expand=True, pady=4)
        self.cal_result = tk.StringVar()
        ttk.Label(t, textvariable=self.cal_result, font=FONT_B, anchor="e", justify="right").pack(fill="x")
        self.fit_pending = None

    def _build_met_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  מטאו  ")
        pane = ttk.PanedWindow(t, orient="horizontal")
        pane.pack(fill="both", expand=True)
        ff = ttk.Frame(pane)
        tf = ttk.Frame(pane)
        pane.add(ff, weight=1)
        pane.add(tf, weight=1)
        self.met_fig = Figure(figsize=(6, 5), dpi=96, constrained_layout=True)
        self.met_canvas = FigureCanvasTkAgg(self.met_fig, master=ff)
        self.met_canvas.get_tk_widget().pack(fill="both", expand=True)
        cols = ("dir", "spd", "rho", "p", "t", "h")
        heads = ("רוח מ- [°]", "רוח [מ'/ש']", "צפיפות", "לחץ [hPa]", "טמפ' [°C]", "גובה MSL [מ']")
        self.met_tree = ttk.Treeview(tf, columns=cols, show="headings")
        for c, h in zip(cols, heads):
            self.met_tree.heading(c, text=h)
            self.met_tree.column(c, width=72, minwidth=50, anchor="center", stretch=True)
        self.met_tree.pack(fill="both", expand=True)

    def _build_bridge_tab(self):
        t = ttk.Frame(self.nb, padding=6)
        self.nb.add(t, text="  גשר JSON  ")
        ttk.Label(t, anchor="e", justify="right", wraplength=900, text=(
            "הפרויקט האחר כותב בקשה לתיקייה inbox (קודם כ-name.json.tmp ואז שינוי שם ל-name.json). "
            "התשובה נכתבת ל-outbox בשם name.result.json. פורמט הבקשה מתואר ב-README ובתיקייה examples.")).pack(fill="x")
        r = ttk.Frame(t)
        r.pack(fill="x", pady=4)
        self.bridge_dir = tk.StringVar(value=os.path.join(BASE_DIR, "exchange"))
        self.btn_bridge = ttk.Button(r, text="התחל האזנה", style="Accent.TButton", command=self.on_bridge_toggle)
        self.btn_bridge.pack(side="left")
        ttk.Button(r, text="בחר…", command=lambda: self.bridge_dir.set(
            filedialog.askdirectory(initialdir=self.bridge_dir.get()) or self.bridge_dir.get())).pack(side="left", padx=4)
        ttk.Entry(r, textvariable=self.bridge_dir).pack(side="left", fill="x", expand=True, padx=4)
        ttk.Label(r, text="תיקיית החלפה").pack(side="left")
        self.bridge_log = tk.Text(t, height=20, font=MONO)
        self.bridge_log.tag_configure("r", justify="right")
        self.bridge_log.pack(fill="both", expand=True)

    # ================= עזרים =================
    def _met_src_changed(self):
        src = self.met_src.get()
        std = src == "standard"
        for e in (self.e_temp, self.e_pres, self.e_wspd, self.e_wdir):
            e.entry.configure(state="normal" if std else "disabled")
        self.e_time.entry.configure(state="normal" if src == "live" else "disabled")
        self.atmo_key = None

    def _run(self, name, fn, done):
        if self.busy:
            messagebox.showinfo("עסוק", "חישוב אחר עדיין רץ")
            return
        self.busy = True
        self.status.set(f"{name}…")
        self.progress.start(12)

        def worker():
            try:
                res = fn()
                self.q.put(("ok", done, res, name))
            except Exception as e:
                self.q.put(("err", None, (e, traceback.format_exc()), name))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind, done, payload, name = self.q.get_nowait()
                if kind == "log":
                    self.bridge_log.insert("end", payload + "\n", "r")
                    self.bridge_log.see("end")
                    continue
                self.busy = False
                self.progress.stop()
                if self.met_dirty:
                    self.met_dirty = False
                    self._show_met()
                if kind == "ok":
                    self.status.set(f"{name}: הסתיים")
                    try:
                        done(payload)
                    except Exception as e:
                        traceback.print_exc()
                        messagebox.showerror("שגיאה בהצגה", str(e))
                else:
                    e, tb = payload
                    print(tb)
                    self.status.set(f"{name}: שגיאה")
                    messagebox.showerror("שגיאה", str(e))
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _angle(self, entry, name):
        return angle_to_rad(entry.get(name=name), self.unit.get())

    def _site(self):
        return (self.e_lat.get(name="קו רוחב"), self.e_lon.get(name="קו אורך"), self.e_alt.get(name="גובה לוע"))

    def _met_inputs(self):
        """אוסף ומאמת את הגדרות המטאו בתהליכון הראשי (Tkinter אינו בטוח לשימוש מתהליכון אחר)."""
        lat, lon, alt = self._site()
        src = self.met_src.get()
        inp = {"src": src, "lat": lat, "lon": lon, "alt": alt, "file": self.met_file.get(), "when": None,
               "temp": None, "pres": None, "wspd": 0.0, "wdir": 0.0}
        if src == "live":
            ts = self.e_time.var.get().strip()
            if ts:
                try:
                    w = datetime.fromisoformat(ts.replace("Z", "+00:00").replace(" ", "T"))
                except ValueError:
                    raise ValueError("שעת תחזית לא תקינה. פורמט: 2026-11-09 12:00")
                inp["when"] = w if w.tzinfo else w.replace(tzinfo=timezone.utc)
        elif src == "standard":
            inp["temp"] = self.e_temp.get(allow_empty=True, name="טמפ' בקרקע")
            inp["pres"] = self.e_pres.get(allow_empty=True, name="לחץ בקרקע")
            inp["wspd"] = self.e_wspd.get(name="מהירות רוח")
            inp["wdir"] = self.e_wdir.get(name="כיוון רוח")
        elif not inp["file"]:
            raise ValueError("לא נבחר קובץ מטאו")
        inp["key"] = (src, round(lat, 4), round(lon, 4), round(alt, 1), str(inp["when"]), inp["temp"], inp["pres"],
                      inp["wspd"], inp["wdir"], inp["file"])
        return inp

    @staticmethod
    def _build_atmo(inp):
        """בניית פרופיל מטאו — ללא גישה ל-Tk (רץ בתהליכון רקע)."""
        src, lat, lon, alt = inp["src"], inp["lat"], inp["lon"], inp["alt"]
        if src == "live":
            return profile_from_open_meteo(lat, lon, inp["when"], alt)
        if src == "standard":
            return AtmosphereProfile.standard(alt, inp["temp"], inp["pres"], inp["wspd"], inp["wdir"]), {"source": "standard"}
        if src == "csv":
            return load_met_csv(inp["file"]), {"source": "csv"}
        with open(inp["file"], encoding="utf-8-sig") as f:
            spec = json.load(f)
        spec = spec.get("met", spec)
        spec.setdefault("source", "inline")
        spec.setdefault("lat", lat)
        spec.setdefault("lon", lon)
        return profile_from_spec(spec, alt)

    def _atmo_for(self, inp):
        """מחזיר פרופיל מהמטמון, או טוען מחדש אם ההגדרות השתנו (רץ בתהליכון רקע)."""
        if self.atmo is None or self.atmo_key != inp["key"] or inp["src"] == "live" and self._live_stale():
            prof, meta = self._build_atmo(inp)
            self.atmo, self.atmo_meta, self.atmo_key = prof, meta, inp["key"]
            self.atmo_loaded_at = datetime.now(timezone.utc)
            self.met_dirty = True
        return self.atmo

    def _live_stale(self):
        """תחזית חיה נטענת מחדש אחרי 30 דקות."""
        t = getattr(self, "atmo_loaded_at", None)
        return t is None or (datetime.now(timezone.utc) - t).total_seconds() > 1800

    def _fp(self, **kw):
        lat, lon, alt = self._site()
        fp = FireParams(qe=0.0, azimuth=0.0, mv=self.e_mv.get(name="מהירות לוע"), latitude=math.radians(lat),
                        gun_alt=alt, target_alt=alt, dt=self.e_dt.get(name="צעד"),
                        drag_factor=self.e_fd.get(name="fD"), lift_factor=self.e_fl.get(name="fL"),
                        coriolis=self.coriolis.get(), earth_curvature=self.curv.get())
        if fp.mv <= 0 or fp.dt <= 0 or fp.dt > 0.2:
            raise ValueError("מהירות לוע חייבת להיות חיובית, וצעד האינטגרציה בין 0 ל-0.2 ש'")
        return replace(fp, **kw)

    # ================= מטאו ומיקום =================
    def on_geocode(self):
        name = self.place_var.get().strip()
        if not name:
            return
        self._run("חיפוש מיקום", lambda: geocode(name), self._geocode_done)

    def _geocode_done(self, res):
        self.places = res
        if not res:
            messagebox.showinfo("חיפוש", "לא נמצאו תוצאות")
            return
        self.place_combo["values"] = [p["label"] for p in res]
        self.place_combo.current(0)
        self.on_place_selected()

    def on_place_selected(self, _e=None):
        i = self.place_combo.current()
        if i < 0 or i >= len(self.places):
            return
        p = self.places[i]
        self.e_lat.set(f"{p['lat']:.5f}")
        self.e_lon.set(f"{p['lon']:.5f}")
        if p.get("elevation_m") is not None:
            self.e_alt.set(f"{p['elevation_m']:.0f}")

    def on_pick_met(self):
        ft = [("JSON", "*.json")] if self.met_src.get() == "json" else [("CSV", "*.csv")]
        p = filedialog.askopenfilename(filetypes=ft + [("All", "*.*")], initialdir=os.path.join(BASE_DIR, "data"))
        if p:
            self.met_file.set(p)

    def on_load_met(self):
        try:
            inp = self._met_inputs()
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return
        self.atmo = None  # כפיית טעינה מחדש
        self._run("טעינת מטאו", lambda: self._atmo_for(inp), lambda _r: self.nb.select(4))

    def _show_met(self):
        a = self.atmo
        if a is None:
            return
        m = self.atmo_meta or {}
        extra = f" | זמן תקף: {m['valid_time_utc']} UTC" if m.get("valid_time_utc") else ""
        self.met_status.set(a.description + extra)
        self.met_tree.delete(*self.met_tree.get_children())
        for r in a.summary():
            self.met_tree.insert("", "end", values=(r["wind_from_deg"], r["wind_speed_mps"], r["density_kgm3"],
                                                    r["pressure_hpa"], r["temp_c"], r["alt_msl_m"]))
        hs = [a.surface_alt + i * 100 for i in range(0, int((25000 - a.surface_alt) / 100))]
        T, W, D = [], [], []
        from .atmosphere import wind_components_to_from
        for h in hs:
            rho, snd, t, p, we, wn = a.at(h)
            s, d = wind_components_to_from(we, wn)
            T.append(t - 273.15); W.append(s); D.append(d)
        f = self.met_fig
        f.clear()
        ax1, ax2, ax3 = f.subplots(1, 3, sharey=True)
        km = [h / 1000 for h in hs]
        ax1.plot(T, km, color="#c0392b"); ax1.set_xlabel("Temperature [°C]"); ax1.set_ylabel("Altitude MSL [km]")
        ax2.plot(W, km, color="#2471a3"); ax2.set_xlabel("Wind speed [m/s]")
        ax3.plot(D, km, ".", ms=2, color="#117a65"); ax3.set_xlabel("Wind from [°]"); ax3.set_xlim(0, 360)
        for ax in (ax1, ax2, ax3):
            ax.grid(alpha=0.3)
        f.suptitle(a.description, fontsize=9)
        self.met_canvas.draw_idle()

    def on_load_proj(self):
        p = filedialog.askopenfilename(filetypes=[("JSON", "*.json")], initialdir=os.path.join(BASE_DIR, "data", "projectiles"))
        if not p:
            return
        try:
            self.projectile = load_projectile(p)
            self.proj_name.set(self.projectile.name)
        except Exception as e:
            messagebox.showerror("שגיאה בקובץ פגז", str(e))

    # ================= מסלול =================
    def on_traj(self):
        try:
            inp = self._met_inputs()
            talt = self.t_talt.get(allow_empty=True, name="גובה פגיעה")
            fp = self._fp(qe=self._angle(self.t_qe, "הגבהה"), azimuth=self._angle(self.t_az, "אזימוט"))
            if talt is not None:
                fp = replace(fp, target_alt=talt)
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return

        def job():
            atmo = self._atmo_for(inp)
            return simulate(self.projectile, atmo, fp), fp
        self._run("חישוב מסלול", job, self._traj_done)

    def _write(self, txt, lines):
        txt.delete("1.0", "end")
        for tag, line in lines:
            txt.insert("end", line + "\n", tag)

    def _impact_lines(self, imp):
        return [
            ("r", f"טווח אופקי: {imp['ground_range_m']:,.1f} מ'"),
            ("r", f"סטייה צידית: {abs(imp['drift_z_m']):,.1f} מ' {'ימינה' if imp['drift_z_m'] >= 0 else 'שמאלה'}"
                  f" = {fmt_angle(imp['deviation'])}"),
            ("r", f"זמן מעוף: {imp['time_of_flight_s']:.2f} ש'"),
            ("r", f"קודקוד: {imp['apex_height_m']:,.0f} מ' מעל הלוע ({imp['max_ordinate_msl_m']:,.0f} מ' מעל פני הים)"),
            ("r", f"מהירות פגיעה: {imp['impact_velocity_mps']:.1f} מ'/ש' (מאך {imp['impact_mach']:.2f})"),
            ("r", f"זווית נפילה: {fmt_angle(imp['angle_of_fall'])}"),
            ("r", f"ספין: {imp['spin_muzzle_rps']:.0f} ← {imp['spin_impact_rps']:.0f} סל'/ש'"),
            ("r", f"Sg בלוע: {imp['sg_muzzle']:.2f}  |  Sg מינימלי: {imp['sg_min']:.2f}"),
            ("r", f"זווית מנוחה מרבית: {fmt_angle(imp['max_yaw_repose'])}"),
        ]

    def _met_line(self):
        m = self.atmo_meta or {}
        s = self.atmo.description if self.atmo else ""
        if m.get("valid_time_utc"):
            s += f" | {m['valid_time_utc']} UTC"
        return ("r", f"מטאו: {s}")

    def _traj_done(self, payload):
        res, fp = payload
        lines = [("h", "תוצאות מסלול")]
        lines.append(("r", f"הגבהה {fmt_angle(both(fp.qe))} | אזימוט {fmt_angle(both(fp.azimuth))} | V0 {fp.mv:.0f} מ'/ש'"))
        if not res.ok:
            lines.append(("w", res.message))
        else:
            lines += self._impact_lines(res.impact)
            for w in stability_warnings(res):
                lines.append(("w", "⚠ " + w))
        lines.append(self._met_line())
        self._write(self.traj_txt, lines)
        self._plot_traj(self.traj_fig, self.traj_canvas, res, title=f"QE {rad_to_mils(fp.qe):.1f} mils")

    def _plot_traj(self, fig, canvas, res, title=""):
        fig.clear()
        if not res.t:
            canvas.draw_idle()
            return
        ax = fig.subplots(2, 2)
        xk = [v / 1000 for v in res.x]
        ax[0, 0].plot(xk, res.y, color="#1f4e79")
        ax[0, 0].set_xlabel("Range [km]"); ax[0, 0].set_ylabel("Height above muzzle [m]")
        ax[0, 0].set_title("Trajectory", fontsize=10)
        ax[0, 1].plot(xk, res.z, color="#a04000")
        ax[0, 1].set_xlabel("Range [km]"); ax[0, 1].set_ylabel("Drift [m] (+right)")
        ax[0, 1].set_title("Lateral deviation", fontsize=10)
        ax[1, 0].plot(res.t, res.vel, color="#196f3d", label="Velocity [m/s]")
        a2 = ax[1, 0].twinx()
        a2.plot(res.t, res.mach, color="#7d3c98", ls="--", label="Mach")
        ax[1, 0].set_xlabel("Time [s]"); ax[1, 0].set_ylabel("Velocity [m/s]"); a2.set_ylabel("Mach")
        ax[1, 0].set_title("Velocity / Mach", fontsize=10)
        ax[1, 1].plot(res.t, [math.degrees(a) for a in res.yaw_repose], color="#b03a2e")
        a3 = ax[1, 1].twinx()
        a3.plot(res.t, [p / (2 * math.pi) for p in res.spin], color="#566573", ls="--")
        ax[1, 1].set_xlabel("Time [s]"); ax[1, 1].set_ylabel("Yaw of repose [deg]"); a3.set_ylabel("Spin [rev/s]")
        ax[1, 1].set_title("Yaw of repose / spin", fontsize=10)
        for a in ax.flat:
            a.grid(alpha=0.3)
        fig.suptitle(title, fontsize=10)
        canvas.draw_idle()

    # ================= פתרון ירי =================
    def on_solve(self):
        try:
            inp = self._met_inputs()
            fp = self._fp()
            lat, lon, alt = self._site()
            if self.s_mode.get() == "coords":
                tl, tn = self.s_lat.get(name="קו רוחב מטרה"), self.s_lon.get(name="קו אורך מטרה")
                rng, azd = inverse(lat, lon, tl, tn)
                az = math.radians(azd)
            else:
                rng = self.s_rng.get(name="טווח")
                az = self._angle(self.s_az, "אזימוט")
            talt = self.s_talt.get(allow_empty=True, name="גובה מטרה")
            talt = alt if talt is None else talt
            group = self.s_group.get()
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return

        def job():
            atmo = self._atmo_for(inp)
            return solve(self.projectile, atmo, fp, rng, az, talt, group)
        self._run("פתרון ירי", job, self._solve_done)

    def _solve_done(self, r):
        traj = r.pop("_trajectory", None)
        if not r["ok"]:
            self._write(self.solve_txt, [("h", "פתרון ירי"), ("w", r["error"]), self._met_line()])
            self.solve_fig.clear(); self.solve_canvas.draw_idle()
            return
        lines = [("h", "פתרון ירי"),
                 ("h", f"הגבהה: {fmt_angle(r['qe'])}"),
                 ("h", f"אזימוט ירי: {fmt_angle(r['fire_azimuth'])}"),
                 ("r", f"אזימוט למטרה: {fmt_angle(r['target_azimuth'])}"),
                 ("r", f"תיקון כיוון: {fmt_angle(r['deflection_correction'])}  (שלילי = שמאלה)"),
                 ("r", f"טווח למטרה: {r['target_range_m']:,.1f} מ' | שגיאה שארית: {r['residual_range_error_m']:.2f} מ'"),
                 ("r", f"טווח מרבי בתנאים אלה: {r['max_range_m']:,.0f} מ' בהגבהה {fmt_angle(r['qe_max_range'])}"),
                 ("r", "")]
        lines += self._impact_lines(r["impact"])
        for w in r.get("warnings", []):
            lines.append(("w", "⚠ " + w))
        lines.append(self._met_line())
        self._write(self.solve_txt, lines)
        if traj is not None:
            self._plot_traj(self.solve_fig, self.solve_canvas, traj,
                            title=f"Solution: QE {r['qe']['mils']:.1f} mils, AZ {r['fire_azimuth']['mils']:.1f} mils")

    # ================= טבלת ירי =================
    def on_table(self):
        try:
            inp = self._met_inputs()
            fp = self._fp(azimuth=self._angle(self.tb_az, "אזימוט"))
            a = self._angle(self.tb_start, "התחלה")
            b = self._angle(self.tb_end, "סוף")
            st = self._angle(self.tb_step, "צעד")
            if st <= 0 or b < a:
                raise ValueError("טווח זוויות לא תקין")
            if (b - a) / st > 400:
                raise ValueError("יותר מ-400 שורות — הגדל את הצעד")
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return

        def job():
            atmo = self._atmo_for(inp)
            return firing_table(self.projectile, atmo, fp, a, b, st)
        self._run("טבלת ירי", job, self._table_done)

    def _table_done(self, payload):
        rows, warns = payload
        self.last_table = rows
        self.table.delete(*self.table.get_children())
        cols = list(reversed(TABLE_COLUMNS))
        for r in rows:
            if "error" in r:
                vals = [""] * (len(cols) - 2) + [r["qe_deg"], r["qe_mils"]]
            else:
                vals = [r[c] for c in cols]
            self.table.insert("", "end", values=vals)
        self.table_warn.set("\n".join(warns[:6]) + (f"\n…ועוד {len(warns) - 6}" if len(warns) > 6 else ""))

    def on_export_table(self):
        if not self.last_table:
            messagebox.showinfo("ייצוא", "אין טבלה לייצוא — חשב קודם")
            return
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")],
                                         initialfile="firing_table.csv")
        if p:
            write_table_csv(self.last_table, p)
            self.status.set(f"נשמר: {p}")

    # ================= כיול =================
    def on_add_cal(self):
        try:
            qe = self.c_qe.get(name="הגבהה")
            az = self.c_az.get(name="אזימוט")
            rng = self.c_rng.get(name="טווח שנמדד")
            dr = self.c_dr.get(allow_empty=True, name="סחיפה")
            talt = self.c_talt.get(allow_empty=True, name="גובה פגיעה")
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return
        u = "מיל" if self.unit.get() == "mils" else "°"
        self.cal_tree.insert("", "end", values=("" if talt is None else talt, "", "" if dr is None else dr, "", "", rng,
                                                f"{az} {u}", f"{qe} {u}"),
                             tags=(json.dumps({"qe": qe, "az": az, "rng": rng, "dr": dr, "talt": talt, "unit": self.unit.get()}),))
        self.c_rng.set("")
        self.c_dr.set("")

    def on_calibrate(self):
        items = self.cal_tree.get_children()
        if not items:
            messagebox.showinfo("כיול", "הוסף לפחות נקודה אחת")
            return
        try:
            inp = self._met_inputs()
            fp = self._fp()
        except ValueError as e:
            messagebox.showerror("קלט", str(e))
            return
        pts = []
        for i in items:
            d = json.loads(self.cal_tree.item(i, "tags")[0])
            p = {"qe": angle_to_rad(d["qe"], d["unit"]), "azimuth": angle_to_rad(d["az"], d["unit"]), "range_m": d["rng"]}
            if d["dr"] is not None:
                p["drift_mils"] = d["dr"] if d["unit"] == "mils" else d["dr"] * 6400 / 360
            if d["talt"] is not None:
                p["target_alt"] = d["talt"]
            pts.append(p)

        def job():
            atmo = self._atmo_for(inp)
            return calibrate(self.projectile, atmo, fp, pts), items
        self._run("כיול", job, self._cal_done)

    def _cal_done(self, payload):
        r, items = payload
        for it, p in zip(items, r["points"]):
            v = list(self.cal_tree.item(it, "values"))
            v[1] = p["sim_drift_mils"]
            v[3] = p["range_error_m"]
            v[4] = p["sim_range_m"]
            self.cal_tree.item(it, values=v)
        self.fit_pending = (r["drag_factor"], r["lift_factor"])
        self.cal_result.set(f"fD = {r['drag_factor']:.5f}   |   fL = {r['lift_factor']:.4f}"
                            f"{'' if r['drift_fitted'] else ' (לא כויל — אין סחיפה)'}"
                            f"   |   RMS שגיאת טווח: {r['rms_range_error_m']:.1f} מ'")
        self.btn_apply.configure(state="normal")

    def on_apply_fit(self):
        if self.fit_pending:
            self.e_fd.set(self.fit_pending[0])
            self.e_fl.set(self.fit_pending[1])
            self.status.set("מקדמי ההתאמה עודכנו")

    # ================= גשר =================
    def on_bridge_toggle(self):
        if self.bridge_stop is None:
            folder = self.bridge_dir.get()
            self.bridge_stop = threading.Event()
            stop = self.bridge_stop
            log = lambda s: self.q.put(("log", None, f"[{datetime.now():%H:%M:%S}] {s}", ""))
            threading.Thread(target=lambda: watch(folder, 0.3, stop, log), daemon=True).start()
            self.btn_bridge.configure(text="עצור האזנה")
        else:
            self.bridge_stop.set()
            self.bridge_stop = None
            self.btn_bridge.configure(text="התחל האזנה")
            self.q.put(("log", None, f"[{datetime.now():%H:%M:%S}] ההאזנה הופסקה", ""))


def main():
    App().mainloop()
