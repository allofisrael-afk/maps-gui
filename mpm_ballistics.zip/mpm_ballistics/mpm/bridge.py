"""גשר JSON: ממשק בקשה/תשובה לפרויקטים אחרים.

שני מצבי עבודה:
  1. חד-פעמי:  python run_bridge.py --request req.json --out result.json
  2. תיקייה:   python run_bridge.py --watch exchange/
     הפרויקט האחר כותב בקשה ל-exchange/inbox/<שם>.json
     (כותבים קודם <שם>.json.tmp ואז משנים שם — כך הסימולציה לא קוראת קובץ חלקי).
     התשובה נכתבת ל-exchange/outbox/<שם>.result.json, והבקשה עוברת ל-exchange/inbox/done/.

מבנה הבקשה — ראו README ואת הדוגמאות בתיקייה examples/.
"""
import json
import math
import os
import shutil
import time
import traceback
from datetime import datetime, timezone

from . import __version__
from .engine import FireParams, simulate, stability_warnings
from .fire_control import solve, firing_table, calibrate
from .geodesy import inverse, direct
from .met_sources import profile_from_spec
from .projectile import load_projectile
from .units import angle_to_rad, both

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _resolve(path):
    if path and not os.path.isabs(path):
        return os.path.join(BASE_DIR, path)
    return path


def _traj_points(res, step=1):
    pts = []
    for i in range(0, len(res.t), max(1, step)):
        pts.append({"t": round(res.t[i], 3), "x": round(res.x[i], 2), "y": round(res.y[i], 2),
                    "z": round(res.z[i], 2), "v": round(res.vel[i], 2), "mach": round(res.mach[i], 4),
                    "spin_rps": round(res.spin[i] / (2 * math.pi), 2),
                    "yaw_repose_deg": round(math.degrees(res.yaw_repose[i]), 4)})
    return pts


def _impact_geo(gun, fire_az_rad, res):
    """מיקום גאוגרפי משוער של נקודת הפגיעה."""
    if not gun or gun.get("lat") is None or not res.ok:
        return None
    imp = res.impact
    az = math.degrees(fire_az_rad) + math.degrees(math.atan2(imp["drift_z_m"], imp["range_x_m"]))
    lat, lon = direct(float(gun["lat"]), float(gun["lon"]), az, imp["ground_range_m"])
    return {"lat": round(lat, 6), "lon": round(lon, 6)}


def build_context(req):
    unit = req.get("angle_unit", "mils")
    gun = req.get("gun", {}) or {}
    gun_alt = float(gun.get("alt_m", 0.0) or 0.0)
    lat_deg = float(gun.get("lat", 0.0) or 0.0)
    proj_spec = req.get("projectile") or {}
    proj = load_projectile(_resolve(proj_spec.get("file")) if proj_spec.get("file") else None)
    met_spec = dict(req.get("met") or {"source": "standard"})
    if (met_spec.get("source") or "").lower() in ("open-meteo", "openmeteo", "live"):
        met_spec.setdefault("lat", gun.get("lat"))
        met_spec.setdefault("lon", gun.get("lon"))
        if met_spec.get("lat") is None:
            raise ValueError("מטאו חי דורש מיקום תותח (gun.lat, gun.lon)")
    if (met_spec.get("source") or "").lower() == "csv":
        met_spec["path"] = _resolve(met_spec["path"])
    atmo, met_meta = profile_from_spec(met_spec, gun_alt)
    fit = req.get("fitting", {}) or {}
    mv = float(req.get("muzzle_velocity_mps", 684.0))
    fp = FireParams(qe=0.0, azimuth=0.0, mv=mv, latitude=math.radians(lat_deg), gun_alt=gun_alt,
                    target_alt=gun_alt, dt=float(req.get("dt_s", 0.02)),
                    drag_factor=float(fit.get("drag_factor", 1.0)), lift_factor=float(fit.get("lift_factor", 1.0)),
                    magnus_factor=float(fit.get("magnus_factor", 1.0)),
                    coriolis=bool(req.get("coriolis", True)), earth_curvature=bool(req.get("earth_curvature", True)))
    met_meta["description"] = atmo.description
    return unit, gun, proj, atmo, met_meta, fp


def process_request(req):
    t0 = time.time()
    out = {"request_id": req.get("request_id"), "mode": req.get("mode"), "status": "ok",
           "engine": f"MPM 4-DOF v{__version__}", "computed_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "warnings": [], "errors": []}
    try:
        mode = (req.get("mode") or "").lower()
        unit, gun, proj, atmo, met_meta, fp = build_context(req)
        out["met_used"] = met_meta
        out["projectile"] = proj.summary()
        out["muzzle_velocity_mps"] = fp.mv
        include_path = bool(req.get("include_path", False))
        path_step = int(req.get("path_step", 10))

        if mode == "trajectory":
            t = req.get("trajectory", {})
            from dataclasses import replace
            tgt_alt = t.get("target_alt_m")
            f = replace(fp, qe=angle_to_rad(float(t["qe"]), unit), azimuth=angle_to_rad(float(t.get("azimuth", 0)), unit),
                        target_alt=float(tgt_alt) if tgt_alt is not None else fp.gun_alt)
            res = simulate(proj, atmo, f, record=include_path)
            if not res.ok:
                raise ValueError(res.message)
            out["results"] = {"qe": both(f.qe), "azimuth": both(f.azimuth), "impact": res.impact,
                              "impact_geo": _impact_geo(gun, f.azimuth, res)}
            out["warnings"] += stability_warnings(res)
            if include_path:
                out["results"]["path"] = _traj_points(res, path_step)

        elif mode == "solve":
            s = req.get("solve", {})
            tgt = s.get("target", {}) or {}
            if tgt.get("lat") is not None:
                if gun.get("lat") is None:
                    raise ValueError("פתרון לפי קואורדינטות מטרה דורש קואורדינטות תותח")
                rng, az_deg = inverse(float(gun["lat"]), float(gun["lon"]), float(tgt["lat"]), float(tgt["lon"]))
                az = math.radians(az_deg)
            else:
                rng = float(tgt["range_m"])
                az = angle_to_rad(float(tgt.get("azimuth", 0)), unit)
            talt = float(tgt.get("alt_m", fp.gun_alt))
            r = solve(proj, atmo, fp, rng, az, talt, s.get("angle_group", "low"))
            traj = r.pop("_trajectory", None)
            if not r["ok"]:
                raise ValueError(r["error"])
            out["warnings"] += r.pop("warnings", [])
            r.pop("ok", None)
            r["target_alt_m"] = talt
            if traj is not None:
                r["impact_geo"] = _impact_geo(gun, angle_to_rad(r["fire_azimuth"]["mils"], "mils"), traj)
                if include_path:
                    r["path"] = _traj_points(traj, path_step)
            out["results"] = r

        elif mode == "table":
            tb = req.get("table", {})
            from dataclasses import replace
            f = replace(fp, azimuth=angle_to_rad(float(tb.get("azimuth", 0)), unit))
            rows, w = firing_table(proj, atmo, f, angle_to_rad(float(tb["qe_start"]), unit),
                                   angle_to_rad(float(tb["qe_end"]), unit), angle_to_rad(float(tb["qe_step"]), unit))
            out["results"] = {"azimuth": both(f.azimuth), "rows": rows}
            out["warnings"] += w

        elif mode == "calibrate":
            cb = req.get("calibrate", {})
            pts = []
            for p in cb.get("points", []):
                d = {"qe": angle_to_rad(float(p["qe"]), unit), "range_m": float(p["range_m"]),
                     "azimuth": angle_to_rad(float(p.get("azimuth", 0)), unit)}
                if p.get("drift") is not None:
                    # סחיפה בקלט ביחידת הזווית שנבחרה; הכיול עובד במילים
                    d["drift_mils"] = float(p["drift"]) if unit == "mils" else float(p["drift"]) * 6400 / 360
                if p.get("target_alt_m") is not None:
                    d["target_alt"] = float(p["target_alt_m"])
                pts.append(d)
            out["results"] = calibrate(proj, atmo, fp, pts, fit_drift=bool(cb.get("fit_drift", True)))
        else:
            raise ValueError(f"mode לא מוכר: {mode!r} (trajectory / solve / table / calibrate)")
    except Exception as e:
        out["status"] = "error"
        out["errors"].append(str(e))
        if os.environ.get("MPM_DEBUG"):
            out["traceback"] = traceback.format_exc()
    out["elapsed_s"] = round(time.time() - t0, 3)
    return out


def _write_atomic(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def process_file(req_path, out_path):
    try:
        with open(req_path, encoding="utf-8-sig") as f:
            req = json.load(f)
    except Exception as e:
        req = {}
        res = {"status": "error", "errors": [f"קובץ בקשה לא תקין: {e}"]}
    else:
        res = process_request(req)
    _write_atomic(out_path, res)
    return res


def watch(folder, poll_s=0.3, stop_event=None, log=print):
    inbox = os.path.join(folder, "inbox")
    outbox = os.path.join(folder, "outbox")
    done = os.path.join(inbox, "done")
    for d in (inbox, outbox, done):
        os.makedirs(d, exist_ok=True)
    log(f"מאזין לבקשות בתיקייה: {os.path.abspath(inbox)}")
    while not (stop_event and stop_event.is_set()):
        for name in sorted(os.listdir(inbox)):
            if not name.lower().endswith(".json"):
                continue
            src = os.path.join(inbox, name)
            if not os.path.isfile(src):
                continue
            stem = name[:-5]
            dst = os.path.join(outbox, stem + ".result.json")
            res = process_file(src, dst)
            try:
                shutil.move(src, os.path.join(done, name))
            except OSError:
                pass
            log(f"{name}: {res.get('status')} ({res.get('elapsed_s', 0)} s)")
        time.sleep(poll_s)
