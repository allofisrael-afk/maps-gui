"""בדיקות שפיות למנוע. הרצה: python tests/self_test.py"""
import math
import os
import sys
from dataclasses import replace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mpm.atmosphere import AtmosphereProfile
from mpm.engine import FireParams, simulate
from mpm.fire_control import solve, calibrate
from mpm.geodesy import inverse, direct
from mpm.projectile import load_projectile
from mpm.units import mils_to_rad

P = load_projectile()
A = AtmosphereProfile.standard(0)
FP = FireParams(qe=mils_to_rad(500), azimuth=0.0, mv=684, latitude=math.radians(32))
results = []


def check(name, cond, info=""):
    results.append(cond)
    print(f"[{'OK' if cond else 'FAIL'}] {name} {info}")


r1 = simulate(P, A, replace(FP, dt=0.005), record=False).ground_range
r2 = simulate(P, A, replace(FP, dt=0.05), record=False).ground_range
check("התכנסות צעד האינטגרציה", abs(r1 - r2) < 0.5, f"({r1:.2f} / {r2:.2f} מ')")

r = simulate(P, A, replace(FP, coriolis=False), record=False)
check("סחיפה ימינה בפיתול ימני", r.impact["drift_z_m"] > 0, f"({r.impact['drift_z_m']:.1f} מ')")

north = simulate(P, A, replace(FP, azimuth=0.0, lift_factor=0, magnus_factor=0), record=False)
check("קוריוליס מסיט ימינה בחצי הכדור הצפוני", north.impact["drift_z_m"] > 0, f"({north.impact['drift_z_m']:.1f} מ')")
east = simulate(P, A, replace(FP, azimuth=math.pi / 2), record=False).ground_range
west = simulate(P, A, replace(FP, azimuth=3 * math.pi / 2), record=False).ground_range
check("אפקט אטווש: ירי מזרחה ארוך מירי מערבה", east > west, f"({east - west:.1f} מ')")

s = solve(P, A, FP, 14000.0, mils_to_rad(800), 0.0, "low")
check("פתרון ירי מתכנס", s["ok"] and abs(s["residual_range_error_m"]) < 1.0,
      f"(שארית {s.get('residual_range_error_m')} מ')")

pts = []
for q in (300, 700):
    rr = simulate(P, A, replace(FP, qe=mils_to_rad(q), drag_factor=1.06, lift_factor=1.25), record=False)
    pts.append({"qe": mils_to_rad(q), "range_m": rr.ground_range, "drift_mils": rr.impact["deviation"]["mils"]})
c = calibrate(P, A, FP, pts)
check("כיול משחזר מקדמים ידועים", abs(c["drag_factor"] - 1.06) < 2e-3 and abs(c["lift_factor"] - 1.25) < 0.02,
      f"(fD={c['drag_factor']}, fL={c['lift_factor']})")

d, az = inverse(31.25, 34.79, 31.36, 34.89)
la, lo = direct(31.25, 34.79, az, d)
check("גאודזיה: הלוך-חזור", abs(la - 31.36) < 1e-7 and abs(lo - 34.89) < 1e-7, f"({d:.2f} מ', {az:.3f}°)")

print("\nכל הבדיקות עברו" if all(results) else "\nיש בדיקות שנכשלו")
sys.exit(0 if all(results) else 1)
