"""גשר JSON לסימולציית MPM.

    python run_bridge.py --request examples/request_solve.json --out result.json
    python run_bridge.py --watch exchange
"""
import argparse
import json
import sys

from mpm.bridge import process_file, watch


def main():
    ap = argparse.ArgumentParser(description="MPM 4-DOF — JSON bridge")
    ap.add_argument("--request", help="קובץ בקשה JSON להרצה חד-פעמית")
    ap.add_argument("--out", help="קובץ תשובה (ברירת מחדל: <request>.result.json)")
    ap.add_argument("--watch", help="תיקייה להאזנה (inbox/outbox)")
    ap.add_argument("--poll", type=float, default=0.3, help="מרווח בדיקת התיקייה בשניות")
    a = ap.parse_args()
    if a.watch:
        try:
            watch(a.watch, a.poll)
        except KeyboardInterrupt:
            pass
        return 0
    if a.request:
        out = a.out or (a.request[:-5] if a.request.lower().endswith(".json") else a.request) + ".result.json"
        res = process_file(a.request, out)
        print(json.dumps({"status": res.get("status"), "out": out, "errors": res.get("errors")}, ensure_ascii=False))
        return 0 if res.get("status") == "ok" else 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
